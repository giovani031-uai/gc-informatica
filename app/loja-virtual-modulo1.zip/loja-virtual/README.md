# GC Informática — Loja Virtual (Módulo 1: estrutura base)

## O que já está pronto neste módulo

- Projeto Next.js 14 + TypeScript + Tailwind CSS configurado
- Estrutura de pastas do projeto (app, components, lib, public)
- Identidade visual inicial: cores, tipografia (Fraunces + Inter)
- Header responsivo (com menu mobile) e Footer completo
- Arquivo central de configuração da loja (`lib/config.ts`)
- Homepage provisória, só para validar que tudo está funcionando

Ainda **não** há: catálogo, carrinho, checkout, login ou admin — isso vem
nos próximos módulos, um de cada vez.

## Como instalar e rodar no Windows com VS Code

### 1. Pré-requisitos

Baixe e instale o **Node.js** (versão 18 ou superior): https://nodejs.org
(baixe a versão "LTS"). O instalador já inclui o `npm`.

### 2. Abrir o projeto no VS Code

1. Extraia a pasta `loja-virtual` em um local de fácil acesso (ex.: `C:\Projetos\loja-virtual`)
2. Abra o VS Code
3. Vá em **File > Open Folder** e selecione a pasta `loja-virtual`
4. Abra o terminal integrado: **Terminal > New Terminal** (ou `Ctrl+ ` )

### 3. Instalar as dependências

No terminal do VS Code, cole e execute:

```
npm install
```

Isso vai baixar todos os pacotes necessários (pode levar alguns minutos).

### 4. Rodar o projeto

```
npm run dev
```

Depois abra o navegador em **http://localhost:3000**. Você deve ver a
página inicial provisória, com o header e o footer já funcionando.

Para parar o servidor, volte ao terminal e pressione `Ctrl+C`.

## Próximos passos

Confirme que essa parte está funcionando corretamente no seu computador
(inclusive testando o menu mobile diminuindo a janela do navegador) antes
de avançarmos para o **Módulo 2**, que vai trazer a homepage completa:
hero, categorias, produtos em destaque, benefícios, depoimentos e FAQ.
