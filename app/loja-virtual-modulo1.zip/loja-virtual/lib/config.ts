/**
 * Configuração central da loja.
 *
 * No módulo do Admin, esses valores vão passar a vir do banco de dados
 * (tabela "settings"), para que o lojista edite tudo pelo painel sem
 * precisar mexer em código. Por enquanto ficam aqui como fonte única,
 * para nenhum componente ter número de WhatsApp, nome da loja etc.
 * "hardcoded" espalhado pelo projeto.
 */
export const storeConfig = {
  name: "GC Informática",
  tagline: "Tecnologia com curadoria de verdade",
  whatsapp: {
    number: "5531991020519", // formato: código do país + DDD + número, sem espaços ou símbolos
    defaultMessage: (productName?: string) =>
      productName
        ? `Olá! Tenho interesse no produto ${productName}.`
        : "Olá! Vim pelo site e gostaria de tirar uma dúvida.",
  },
  social: {
    instagram: "https://instagram.com/",
  },
  contactEmail: "contato@vertice.com.br",
};
